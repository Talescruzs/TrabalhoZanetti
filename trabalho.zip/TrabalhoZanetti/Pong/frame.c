#include "frame.h"
// PRESETS PERSONAGEM:
struct Frame personagem_principal_f = {"./imagens/personagem.png","./imagens/personagem_dano.png","./imagens/ataque_mao.png", "./imagens/ataque_mao_dano.png",120,240,4,3};
struct Frame personagem_adaga_f = {"./imagens/caminhar_adaga.png","./imagens/caminhar_adaga_dano.png","./imagens/ataque_adaga.png", "./imagens/ataque_adaga_dano.png",120,240,4,3};
struct Frame personagem_espada_f = {"./imagens/caminhar_espada.png","./imagens/caminhar_espada_dano.png","./imagens/ataque_espada.png", "./imagens/ataque_espada_dano.png",150,240,4,3};
struct Frame personagem_machado_f = {"./imagens/caminhar_machado.png","./imagens/caminhar_machado_dano.png","./imagens/caminhar_machado.png", "./imagens/caminhar_machado_dano.png",210,320,4,3};
struct Frame personagem_inimigo_f = {"./imagens/slime_azul.png","./imagens/slime_azul.png","./imagens/slime_azul.png", "./imagens/personagem.png",105,120,4,3};
struct Frame personagem_chefe_f = {"./imagens/slime_boss.png","./imagens/slime_boss.png","./imagens/slime_boss.png", "./imagens/slime_boss.png",315,360,4,3};
// PRESETS ITEM:
struct Frame teste_bola = {"./imagens/bola.png","./imagens/bola.png","./imagens/bola.png", "./imagens/personagem.png",77,77,1,1};
