# **Trabalho da disciplina de algoritmos e programação**
### **Integrantes:**
* [Tales Cruz](https://github.com/Talescruzs)
* [Rian](https://github.com/Rian-Rasch)
* [Marcus](https://github.com/TheMarcus1501)
<p><b>Todos alunos de primeiro semestre de Engenharia de Telecomunicações da UFSM</b></p>

### **Descrição:**
O objetivo inicial deste trabalho é criar um jogo utilizando a linguagem de programação C e a biblioteca [Allegro](https://liballeg.org), aplicando os conhecimentos adquiridos durante o semestre.
